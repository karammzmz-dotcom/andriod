# Arduboy Catacombs for Android

Android port project for the supplied Arduboy3D Catacombs source.

## Controls

- No on-screen controls are displayed.
- Keyboard and connected game controllers are supported through Android key events.

## Build on GitHub

1. Upload the **contents** of this folder to the root of a GitHub repository (so `.github/` and `app/` are at the repository root).
2. Open the repository's **Actions** tab.
3. Run **Build Android APK** (or push to `main` / `master`).
4. Download the `Catacombs-Android-debug` artifact from the completed run.
5. Extract the artifact ZIP and install `app-debug.apk` on your Android device.

## Workflows

- `.github/workflows/build.yml`: installs the required Android SDK packages and builds the APK.
- `.github/workflows/unzip.yml`: extracts the included `Arduboy3D-1.0.zip` source archive, then builds the APK.

The original source archive is included in this project, so you do not need to upload it separately.
