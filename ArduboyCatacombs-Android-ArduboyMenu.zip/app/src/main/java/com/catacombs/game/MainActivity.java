package com.catacombs.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.*;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;

public class MainActivity extends Activity {
    static { System.loadLibrary("catacombs"); }
    private static native int[] nativeFrame(int keys);
    private static native boolean nativeLoadHex(String path);
    private static native void nativeStopHex();
    private static native short[] nativeDrainAudio(int samples);
    private static native void nativeResetGame();
    private static native void nativeSetAudioEnabled(boolean enabled);

    private final ArrayList<GameEntry> games = new ArrayList<>();
    private boolean playing = false;
    private boolean soundEnabled = true;
    private GameView gameView;
    private MenuView menu;
    private Sfx sfx;

    static class GameEntry {
        final String title, description, asset, license;
        final boolean nativeCatacombs, about;
        GameEntry(String t, String d, String a, String l, boolean nc, boolean ab) {
            title = t; description = d; asset = a; license = l; nativeCatacombs = nc; about = ab;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        sfx = new Sfx();
        loadOfflineLibrary();
        menu = new MenuView(this);
        showMenu();
    }

    private void loadOfflineLibrary() {
        games.clear();
        games.add(new GameEntry("Catacombs of the Damned", "Native dungeon crawler", "", "MIT", true, false));
        try {
            InputStream in = getAssets().open("games.json");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            in.close();
            JSONArray arr = new JSONArray(out.toString("UTF-8"));
            File dir = new File(getFilesDir(), "arduboy"); dir.mkdirs();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String file = o.getString("file");
                File dest = new File(dir, file);
                if (!dest.exists()) {
                    try (InputStream src = getAssets().open("games/" + file); FileOutputStream dst = new FileOutputStream(dest)) {
                        byte[] buf = new byte[8192]; int r;
                        while ((r = src.read(buf)) > 0) dst.write(buf, 0, r);
                    }
                }
                games.add(new GameEntry(o.optString("title", file), o.optString("description", "Arduboy game"),
                        dest.getAbsolutePath(), o.optString("license", ""), false, false));
            }
        } catch (Exception e) {
            // The built-in Catacombs entry stays available if the optional catalogue is absent.
        }
        games.add(new GameEntry("About / Licences", "Credits and GPL-3.0 text", "", "", false, true));
    }

    private void showMenu() {
        playing = false;
        if (gameView != null) { gameView.stop(); gameView = null; }
        nativeStopHex();
        nativeResetGame();
        menu.setGames(games);
        setContentView(menu);
        menu.requestFocus();
    }

    void launch(GameEntry entry) {
        if (entry.about) { showLicenses(); return; }
        if (!entry.nativeCatacombs && !nativeLoadHex(entry.asset)) {
            Toast.makeText(this, "Could not start this Arduboy ROM", Toast.LENGTH_SHORT).show();
            return;
        }
        if (entry.nativeCatacombs) { nativeStopHex(); nativeResetGame(); }
        playing = true;
        FrameLayout host = new FrameLayout(this);
        host.setBackgroundColor(Color.BLACK);
        gameView = new GameView(this, entry.nativeCatacombs);
        host.addView(gameView);
        setContentView(host);
        gameView.setFocusable(true);
        gameView.requestFocus();
        gameView.start();
    }

    private void toggleSound() {
        soundEnabled = !soundEnabled;
        nativeSetAudioEnabled(soundEnabled);
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (!playing && event.getAction() == KeyEvent.ACTION_DOWN && menu != null && menu.handleKey(event.getKeyCode())) {
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onBackPressed() {
        if (playing) showMenu(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (gameView != null) gameView.stop();
        sfx.release();
    }

    private void showLicenses() {
        String msg = "Arduous emulator core copyright James Roeder and contributors · GPL-3.0. No warranty; you may share and modify the GPL-covered program under GPL version 3. The complete licence is bundled in this app and can be viewed below.\n\n"
                + "Catacombs of the Damned: James Howard · MIT. Additional offline ROMs include their catalogue author, declared SPDX licence, source path, and licence text in the bundled credits.\n\n"
                + "Menu: left/right to browse, tap or swipe up to launch. Keyboard: arrows, Enter to launch, M toggles sound. In games: arrows/WASD, Z/Enter=A, X=B. Controllers: D-pad/stick, A/B, Start toggles sound. No on-screen buttons.";
        new AlertDialog.Builder(this).setTitle("ABOUT / LICENCES").setMessage(msg)
                .setNeutralButton("VIEW GPL-3.0", (d, w) -> showGplText())
                .setPositiveButton("CLOSE", null).show();
    }

    private void showGplText() {
        try {
            InputStream in = getAssets().open("licenses/Arduous-GPL-3.0.txt");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            in.close();
            TextView text = new TextView(this);
            text.setText(out.toString("UTF-8"));
            text.setTextColor(Color.WHITE);
            text.setTextSize(11);
            text.setTypeface(Typeface.MONOSPACE);
            text.setPadding(dp(14), dp(12), dp(14), dp(12));
            ScrollView scroll = new ScrollView(this);
            scroll.setBackgroundColor(Color.BLACK);
            scroll.addView(text);
            new AlertDialog.Builder(this).setTitle("GNU GPL VERSION 3").setView(scroll).setPositiveButton("CLOSE", null).show();
        } catch (Exception e) {
            Toast.makeText(this, "GPL text is missing from this build", Toast.LENGTH_LONG).show();
        }
    }

    // ===== Sound: short square-wave effects synthesised in code =====
    // Each tone has a short attack and release ramp, so it starts and stops without a click.
    private static short[] synth(int[] freqs, double stepSec, double vol) {
        final int rate = 44100;
        int stepN = (int) (stepSec * rate);
        int total = stepN * freqs.length;
        int ramp = (int) (0.003 * rate);
        short[] out = new short[total];
        double phase = 0;
        for (int n = 0; n < total; n++) {
            int k = n / stepN;
            phase += freqs[k] / (double) rate;
            if (phase >= 1) phase -= 1;
            double square = phase < 0.5 ? 1 : -1;
            double env = vol * Math.pow(0.001, n / (double) total);
            double attack = Math.min(1.0, n / (double) ramp);
            double release = Math.min(1.0, (total - n) / (double) ramp);
            out[n] = (short) (env * attack * release * square * 32767);
        }
        return out;
    }

    // Writes 16-bit mono PCM as a WAV file, which SoundPool can load.
    private static void writeWav(File f, short[] pcm) throws IOException {
        int dataBytes = pcm.length * 2;
        ByteBuffer b = ByteBuffer.allocate(44 + dataBytes).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes("US-ASCII")).putInt(36 + dataBytes).put("WAVE".getBytes("US-ASCII"));
        b.put("fmt ".getBytes("US-ASCII")).putInt(16).putShort((short) 1).putShort((short) 1)
                .putInt(44100).putInt(44100 * 2).putShort((short) 2).putShort((short) 16);
        b.put("data".getBytes("US-ASCII")).putInt(dataBytes);
        for (short v : pcm) b.putShort(v);
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(b.array()); }
    }

    // SoundPool is built for short effects: it mixes overlapping blips and avoids the
    // stop/restart glitches a single static AudioTrack produces on fast navigation.
    private class Sfx {
        private final SoundPool pool;
        final int move, select, boot;
        Sfx() {
            pool = new SoundPool.Builder()
                    .setMaxStreams(4)
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .build();
            move = load("move", synth(new int[]{1400}, 0.025, 0.25));
            select = load("select", synth(new int[]{523, 659, 784, 1047}, 0.06, 0.3));
            boot = load("boot", synth(new int[]{262, 392, 523, 784}, 0.11, 0.3));
            pool.setOnLoadCompleteListener((p, id, status) -> {
                if (status == 0 && id == boot) p.play(id, 0.8f, 0.8f, 1, 0, 1f);
            });
        }
        private int load(String name, short[] pcm) {
            try {
                File f = new File(getCacheDir(), "sfx_" + name + ".wav");
                writeWav(f, pcm);
                return pool.load(f.getAbsolutePath(), 1);
            } catch (IOException e) {
                return 0;
            }
        }
        void play(int id) {
            if (soundEnabled && id != 0) pool.play(id, 0.8f, 0.8f, 1, 0, 1f);
        }
        void release() { pool.release(); }
    }

    // ===== Black-and-white Arduboy-style menu, drawn at 128x64 and scaled up =====
    private class MenuView extends View {
        private static final int W = 128, H = 64, SPACING = 40;
        private final Bitmap screen = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        private final Canvas c = new Canvas(screen);
        private final Paint fill = new Paint(), stroke = new Paint(), text = new Paint();
        private final Paint blit = new Paint(), invert = new Paint();
        private final Rect src = new Rect(0, 0, W, H), dst = new Rect();
        private final ArrayList<GameEntry> list = new ArrayList<>();
        private final ArrayList<boolean[]> icons = new ArrayList<>();
        private final Handler handler = new Handler(Looper.getMainLooper());
        private int index = 0, flash = 0, frame = 0;
        private float pos = 0;
        private boolean launching = false;
        private float downX, downY;
        private boolean down = false;

        MenuView(Context ctx) {
            super(ctx);
            setBackgroundColor(Color.BLACK);
            setFocusable(true);
            fill.setColor(Color.WHITE);
            fill.setStyle(Paint.Style.FILL);
            fill.setAntiAlias(false);
            stroke.setColor(Color.WHITE);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(1);
            stroke.setAntiAlias(false);
            text.setColor(Color.WHITE);
            text.setTextSize(8);
            text.setTypeface(Typeface.MONOSPACE);
            text.setAntiAlias(false);
            blit.setFilterBitmap(false);
            invert.setFilterBitmap(false);
            invert.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(new float[]{
                    -1, 0, 0, 0, 255,
                    0, -1, 0, 0, 255,
                    0, 0, -1, 0, 255,
                    0, 0, 0, 1, 0})));
        }

        void setGames(List<GameEntry> g) {
            list.clear();
            list.addAll(g);
            icons.clear();
            for (GameEntry e : list) icons.add(makeIcon(e.title));
            if (index >= list.size()) index = Math.max(0, list.size() - 1);
            pos = index;
        }

        // Seeded, mirrored 14x14 pixel icon so each title always gets the same picture.
        private boolean[] makeIcon(String seed) {
            Random r = new Random(seed.hashCode() * 31L + 7);
            boolean[] bits = new boolean[14 * 14];
            for (int y = 0; y < 14; y++) {
                for (int x = 0; x < 7; x++) {
                    boolean on = r.nextFloat() > 0.45f;
                    bits[y * 14 + x] = on;
                    bits[y * 14 + (13 - x)] = on;
                }
            }
            return bits;
        }

        private void drawIcon(boolean[] bits, int x, int y, boolean dim) {
            for (int py = 0; py < 14; py++) {
                for (int px = 0; px < 14; px++) {
                    if (!bits[py * 14 + px]) continue;
                    if (dim && ((px + py) & 1) == 1) continue;
                    c.drawRect(x + px, y + py, x + px + 1, y + py + 1, fill);
                }
            }
        }

        private void drawText(String s, float x, float y, Paint.Align align) {
            text.setTextAlign(align);
            c.drawText(s, x, y - text.ascent(), text);
        }

        void go(int n) {
            int next = Math.max(0, Math.min(list.size() - 1, n));
            if (next != index) {
                index = next;
                sfx.play(sfx.move);
            }
        }

        void launchSelected() {
            if (launching || list.isEmpty()) return;
            final GameEntry entry = list.get(index);
            launching = true;
            flash = 8;
            sfx.play(sfx.select);
            handler.postDelayed(() -> {
                launching = false;
                MainActivity.this.launch(entry);
            }, 400);
        }

        boolean handleKey(int k) {
            switch (k) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                case KeyEvent.KEYCODE_A:
                    go(index - 1); return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                case KeyEvent.KEYCODE_D:
                    go(index + 1); return true;
                case KeyEvent.KEYCODE_DPAD_UP:
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_SPACE:
                case KeyEvent.KEYCODE_BUTTON_A:
                case KeyEvent.KEYCODE_BUTTON_X:
                    launchSelected(); return true;
                case KeyEvent.KEYCODE_M:
                case KeyEvent.KEYCODE_BUTTON_START:
                    MainActivity.this.toggleSound(); return true;
            }
            return false;
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down = true;
                    downX = e.getX();
                    downY = e.getY();
                    return true;
                case MotionEvent.ACTION_UP:
                    if (down) {
                        down = false;
                        handleGesture(e.getX() - downX, e.getY() - downY, e.getX());
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    down = false;
                    return true;
            }
            return true;
        }

        private void handleGesture(float dx, float dy, float upX) {
            float unit = Math.max(40f, getWidth() / 10f);
            if (Math.abs(dx) > unit / 2 && Math.abs(dx) > Math.abs(dy)) {
                int steps = Math.max(1, Math.round(Math.abs(dx) / unit));
                go(index + (dx < 0 ? steps : -steps));
            } else if (dy < -unit / 2 && Math.abs(dy) > Math.abs(dx)) {
                launchSelected();
            } else if (Math.abs(dx) < 20 && Math.abs(dy) < 20) {
                float local = upX / Math.max(1, getWidth());
                if (local > 0.35f && local < 0.65f) launchSelected();
                else go(index + (local < 0.5f ? -1 : 1));
            }
        }

        @Override protected void onDraw(Canvas canvas) {
            pos += (index - pos) * 0.25f;
            if (Math.abs(index - pos) < 0.002f) pos = index;

            screen.eraseColor(Color.BLACK);

            // Title and rule
            drawText("ARDUBOY", 64, 2, Paint.Align.CENTER);
            c.drawRect(40, 11, 88, 12, fill);

            // Icon row, clipped to its band
            c.save();
            c.clipRect(0, 16, W, 36);
            int first = (int) Math.floor(pos) - 3, last = (int) Math.ceil(pos) + 3;
            for (int i = Math.max(0, first); i <= Math.min(list.size() - 1, last); i++) {
                int x = Math.round(64 + (i - pos) * SPACING - 7);
                int y = 18;
                if (i == index) {
                    c.drawRect(x - 2.5f, y - 2.5f, x + 16.5f, y + 16.5f, stroke);
                    drawIcon(icons.get(i), x, y, false);
                } else {
                    drawIcon(icons.get(i), x, y, true);
                }
            }
            c.restore();

            if (!list.isEmpty()) {
                String name = list.get(index).title.toUpperCase(Locale.ROOT);
                if (name.length() > 20) name = name.substring(0, 18) + "..";
                drawText(name, 64, 44, Paint.Align.CENTER);
                if (frame % 40 < 30) {
                    drawText("<", 4, 22, Paint.Align.LEFT);
                    drawText(">", 124, 22, Paint.Align.RIGHT);
                }
                drawText((index + 1) + " / " + list.size(), 64, 55, Paint.Align.CENTER);
            }

            // Scale by an integer factor and centre on screen
            int s = Math.max(1, (int) Math.floor(Math.min(getWidth() / (float) W, getHeight() / (float) H)));
            int w = W * s, h = H * s;
            int l = (getWidth() - w) / 2, t = (getHeight() - h) / 2;
            dst.set(l, t, l + w, t + h);

            canvas.drawColor(Color.BLACK);
            canvas.drawBitmap(screen, src, dst, flash > 0 ? invert : blit);
            if (flash > 0) flash--;
            frame++;
            postInvalidateOnAnimation();
        }
    }

    private class GameView extends SurfaceView implements Runnable {
        private final boolean catacombs;
        private final SurfaceHolder holder;
        private final HashSet<Integer> held = new HashSet<>();
        private volatile boolean running;
        private Thread thread, audioThread;
        private AudioTrack audioTrack;
        private final Bitmap bitmap = Bitmap.createBitmap(128, 64, Bitmap.Config.ARGB_8888);
        private final Paint paint = new Paint();
        private int axisMask = 0;

        GameView(Context c, boolean isCatacombs) {
            super(c);
            catacombs = isCatacombs;
            holder = getHolder();
            paint.setFilterBitmap(false);
            setFocusable(true);
        }

        void start() {
            if (running) return;
            running = true;
            nativeSetAudioEnabled(soundEnabled);
            thread = new Thread(this, "ArduboyFrame");
            thread.start();
            startAudio();
        }

        void startAudio() {
            int min = AudioTrack.getMinBufferSize(44100, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            final AudioTrack out = new AudioTrack(
                    new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
                    new AudioFormat.Builder().setSampleRate(44100).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
                    Math.max(min * 4, 16384), AudioTrack.MODE_STREAM, 0);
            audioTrack = out;
            out.play();
            audioThread = new Thread(() -> {
                while (running) {
                    short[] pcm = nativeDrainAudio(735);
                    if (pcm != null) out.write(pcm, 0, pcm.length, AudioTrack.WRITE_BLOCKING);
                }
            }, "ArduboyAudio");
            audioThread.start();
        }

        void stop() {
            running = false;
            if (thread != null) try { thread.join(500); } catch (InterruptedException ignored) { }
            if (audioThread != null) try { audioThread.join(500); } catch (InterruptedException ignored) { }
            if (audioTrack != null) {
                try { audioTrack.pause(); audioTrack.flush(); audioTrack.release(); } catch (Exception ignored) { }
                audioTrack = null;
            }
        }

        private int mask() {
            int m = axisMask;
            for (int k : held) m |= keyMask(k);
            return m;
        }

        private int keyMask(int k) {
            switch (k) {
                case KeyEvent.KEYCODE_DPAD_LEFT: case KeyEvent.KEYCODE_A: return 1;
                case KeyEvent.KEYCODE_DPAD_RIGHT: case KeyEvent.KEYCODE_D: return 2;
                case KeyEvent.KEYCODE_DPAD_UP: case KeyEvent.KEYCODE_W: return 4;
                case KeyEvent.KEYCODE_DPAD_DOWN: case KeyEvent.KEYCODE_S: return 8;
                case KeyEvent.KEYCODE_Z: case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_SPACE:
                case KeyEvent.KEYCODE_BUTTON_A: case KeyEvent.KEYCODE_BUTTON_X: return 16;
                case KeyEvent.KEYCODE_X: case KeyEvent.KEYCODE_ESCAPE:
                case KeyEvent.KEYCODE_BUTTON_B: case KeyEvent.KEYCODE_BUTTON_Y: return 32;
            }
            return 0;
        }

        @Override public boolean onKeyDown(int k, KeyEvent e) {
            if (k == KeyEvent.KEYCODE_BACK) return false;
            if (k == KeyEvent.KEYCODE_M || k == KeyEvent.KEYCODE_BUTTON_START) {
                toggleSound();
                return true;
            }
            if (keyMask(k) != 0) { held.add(k); return true; }
            return super.onKeyDown(k, e);
        }

        @Override public boolean onKeyUp(int k, KeyEvent e) {
            if (keyMask(k) != 0) { held.remove(k); return true; }
            return super.onKeyUp(k, e);
        }

        @Override public boolean onGenericMotionEvent(MotionEvent e) {
            if ((e.getSource() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK && e.getAction() == MotionEvent.ACTION_MOVE) {
                float x = e.getAxisValue(MotionEvent.AXIS_X), y = e.getAxisValue(MotionEvent.AXIS_Y);
                float hx = e.getAxisValue(MotionEvent.AXIS_HAT_X), hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y);
                if (Math.abs(hx) > 0.4f) x = hx;
                if (Math.abs(hy) > 0.4f) y = hy;
                axisMask = 0;
                if (x < -.45f) axisMask |= 1;
                if (x > .45f) axisMask |= 2;
                if (y < -.45f) axisMask |= 4;
                if (y > .45f) axisMask |= 8;
                return true;
            }
            return super.onGenericMotionEvent(e);
        }

        @Override public boolean onTouchEvent(MotionEvent e) { return true; }

        @Override public void run() {
            final long frameNs = 1_000_000_000L / (catacombs ? 30 : 60);
            long next = System.nanoTime();
            while (running) {
                int[] px = nativeFrame(mask());
                bitmap.setPixels(px, 0, 128, 0, 0, 128, 64);
                if (holder.getSurface().isValid()) {
                    Canvas c = null;
                    try {
                        c = holder.lockCanvas();
                        if (c != null) {
                            c.drawColor(Color.BLACK);
                            float s = Math.min(c.getWidth() / 128f, c.getHeight() / 64f);
                            float w = 128 * s, h = 64 * s, l = (c.getWidth() - w) / 2f, t = (c.getHeight() - h) / 2f;
                            c.drawBitmap(bitmap, null, new RectF(l, t, l + w, t + h), paint);
                        }
                    } finally {
                        if (c != null) holder.unlockCanvasAndPost(c);
                    }
                }
                next += frameNs;
                long wait = next - System.nanoTime();
                if (wait > 0) {
                    try { Thread.sleep(wait / 1_000_000L, (int) (wait % 1_000_000L)); } catch (InterruptedException ignored) { }
                } else {
                    next = System.nanoTime();
                }
            }
        }
    }
}
