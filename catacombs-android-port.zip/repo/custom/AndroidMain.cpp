// AndroidMain.cpp
//
// SDL2 platform glue for "Catacombs of the Damned" (Arduboy3D) on Android.
// Adapted from the project's Windows/SDL port (WinMain.cpp).
//
// Input is physical only: Bluetooth/USB game controllers (SDL_GameController)
// and physical/Bluetooth keyboards. No on-screen touch controls are created.

#include <SDL.h>
#include <vector>
#include "Defines.h"
#include "Game.h"
#include "Map.h"
#include "Draw.h"
#include "Platform.h"
#include "FixedMath.h"
#include "MapGenerator.h"

#define TONES_END 0x8000

static SDL_Window* AppWindow = nullptr;
static SDL_Renderer* AppRenderer = nullptr;
static SDL_Surface* ScreenSurface = nullptr;
static SDL_Texture* ScreenTexture = nullptr;

static uint8_t sBuffer[DISPLAY_WIDTH * DISPLAY_HEIGHT / 8];
static bool isAudioEnabled = true;

// ---------------------------------------------------------------------------
// Keyboard mapping (physical / Bluetooth keyboards only)
// ---------------------------------------------------------------------------
struct KeyMap
{
	SDL_Scancode key;
	uint8_t mask;
};

static const std::vector<KeyMap> KeyMappings =
{
	{ SDL_SCANCODE_LEFT,  INPUT_LEFT  },
	{ SDL_SCANCODE_RIGHT, INPUT_RIGHT },
	{ SDL_SCANCODE_UP,    INPUT_UP    },
	{ SDL_SCANCODE_DOWN,  INPUT_DOWN  },
	{ SDL_SCANCODE_A,     INPUT_LEFT  },
	{ SDL_SCANCODE_D,     INPUT_RIGHT },
	{ SDL_SCANCODE_W,     INPUT_UP    },
	{ SDL_SCANCODE_S,     INPUT_DOWN  },
	{ SDL_SCANCODE_Z,     INPUT_A     },
	{ SDL_SCANCODE_X,     INPUT_B     },
	{ SDL_SCANCODE_J,     INPUT_A     },
	{ SDL_SCANCODE_K,     INPUT_B     },
	{ SDL_SCANCODE_SPACE, INPUT_A     },
	{ SDL_SCANCODE_RETURN,INPUT_B     },
};

// ---------------------------------------------------------------------------
// Game controller support (Bluetooth / USB gamepads)
// ---------------------------------------------------------------------------
static SDL_GameController* ActiveController = nullptr;
static const int ControllerDeadzone = 12000;

static void OpenFirstAvailableController()
{
	for (int i = 0; i < SDL_NumJoysticks(); i++)
	{
		if (SDL_IsGameController(i))
		{
			ActiveController = SDL_GameControllerOpen(i);
			if (ActiveController)
				return;
		}
	}
}

static uint8_t PollControllerInput()
{
	if (!ActiveController)
		return 0;

	if (!SDL_GameControllerGetAttached(ActiveController))
	{
		SDL_GameControllerClose(ActiveController);
		ActiveController = nullptr;
		return 0;
	}

	uint8_t result = 0;

	if (SDL_GameControllerGetButton(ActiveController, SDL_CONTROLLER_BUTTON_DPAD_LEFT))
		result |= INPUT_LEFT;
	if (SDL_GameControllerGetButton(ActiveController, SDL_CONTROLLER_BUTTON_DPAD_RIGHT))
		result |= INPUT_RIGHT;
	if (SDL_GameControllerGetButton(ActiveController, SDL_CONTROLLER_BUTTON_DPAD_UP))
		result |= INPUT_UP;
	if (SDL_GameControllerGetButton(ActiveController, SDL_CONTROLLER_BUTTON_DPAD_DOWN))
		result |= INPUT_DOWN;

	// Left analog stick as an alternative to the D-pad.
	Sint16 axisX = SDL_GameControllerGetAxis(ActiveController, SDL_CONTROLLER_AXIS_LEFTX);
	Sint16 axisY = SDL_GameControllerGetAxis(ActiveController, SDL_CONTROLLER_AXIS_LEFTY);

	if (axisX < -ControllerDeadzone) result |= INPUT_LEFT;
	if (axisX >  ControllerDeadzone) result |= INPUT_RIGHT;
	if (axisY < -ControllerDeadzone) result |= INPUT_UP;
	if (axisY >  ControllerDeadzone) result |= INPUT_DOWN;

	if (SDL_GameControllerGetButton(ActiveController, SDL_CONTROLLER_BUTTON_A))
		result |= INPUT_A;
	if (SDL_GameControllerGetButton(ActiveController, SDL_CONTROLLER_BUTTON_B))
		result |= INPUT_B;
	if (SDL_GameControllerGetButton(ActiveController, SDL_CONTROLLER_BUTTON_X))
		result |= INPUT_A;
	if (SDL_GameControllerGetButton(ActiveController, SDL_CONTROLLER_BUTTON_Y))
		result |= INPUT_B;

	// Shoulder triggers as a convenient alternate fire / action mapping.
	if (SDL_GameControllerGetAxis(ActiveController, SDL_CONTROLLER_AXIS_TRIGGERRIGHT) > 8000)
		result |= INPUT_A;
	if (SDL_GameControllerGetAxis(ActiveController, SDL_CONTROLLER_AXIS_TRIGGERLEFT) > 8000)
		result |= INPUT_B;

	return result;
}

// ---------------------------------------------------------------------------
// Simple square-wave audio synth driving Platform::PlaySound patterns
// ---------------------------------------------------------------------------
constexpr int audioSampleRate = 22050;
static const uint16_t* currentAudioPattern = nullptr;
static int currentPatternBufferPos = 0;

static void Play(const uint16_t* pattern)
{
	currentAudioPattern = pattern;
	currentPatternBufferPos = 0;
}

static void FillAudioBuffer(void* /*udata*/, uint8_t* stream, int len)
{
	int feedPos = 0;

	static int waveSamplesLeft = 0;
	static int noteSamplesLeft = 0;
	static int frequency = 0;
	static bool high = false;

	while (feedPos < len)
	{
		if (!isAudioEnabled)
		{
			while (feedPos < len)
				stream[feedPos++] = 0;
			return;
		}

		if (currentAudioPattern != nullptr)
		{
			if (noteSamplesLeft == 0)
			{
				frequency = currentAudioPattern[currentPatternBufferPos];
				uint16_t duration = currentAudioPattern[currentPatternBufferPos + 1];

				noteSamplesLeft = (audioSampleRate * duration) / 1000;
				waveSamplesLeft = frequency > 0 ? audioSampleRate / frequency : noteSamplesLeft;

				currentPatternBufferPos += 2;
				if (currentAudioPattern[currentPatternBufferPos] == TONES_END)
					currentAudioPattern = nullptr;
			}
		}

		if (frequency == 0)
		{
			while (feedPos < len && (!currentAudioPattern || noteSamplesLeft > 0))
			{
				stream[feedPos++] = 0;
				if (noteSamplesLeft > 0)
					noteSamplesLeft--;
			}
		}
		else
		{
			while (feedPos < len && waveSamplesLeft > 0 && noteSamplesLeft > 0)
			{
				int volume = 32;
				stream[feedPos++] = high ? 128 + volume : 128 - volume;
				waveSamplesLeft--;
				noteSamplesLeft--;
			}

			if (waveSamplesLeft == 0)
			{
				high = !high;
				waveSamplesLeft = audioSampleRate / frequency;
			}
		}
	}
}

// ---------------------------------------------------------------------------
// Platform:: implementation
// ---------------------------------------------------------------------------
void Platform::SetLED(uint8_t, uint8_t, uint8_t)
{
	// No RGB LED on a phone/tablet.
}

void Platform::PutPixel(uint8_t x, uint8_t y, uint8_t colour)
{
	if (x >= DISPLAY_WIDTH || y >= DISPLAY_HEIGHT)
		return;

	uint16_t row_offset = (y & 0xF8) * DISPLAY_WIDTH / 8 + x;
	uint8_t bit = 1 << (y & 7);
	uint8_t data = sBuffer[row_offset] | bit;
	if (!colour) data ^= bit;
	sBuffer[row_offset] = data;
}

static uint8_t GetPixel(uint8_t x, uint8_t y)
{
	uint8_t row = y / 8;
	uint8_t bit_position = y % 8;
	return (sBuffer[(row * DISPLAY_WIDTH) + x] & (1 << bit_position)) >> bit_position;
}

void Platform::FillScreen(uint8_t colour)
{
	for (int y = 0; y < DISPLAY_HEIGHT; y++)
		for (int x = 0; x < DISPLAY_WIDTH; x++)
			PutPixel(x, y, colour);
}

void Platform::DrawSprite(int16_t x, int16_t y, const uint8_t* bitmap, uint8_t /*frame*/)
{
	uint8_t w = bitmap[0];
	uint8_t h = bitmap[1];
	bitmap += 2;

	for (int j = 0; j < h; j++)
	{
		for (int i = 0; i < w; i++)
		{
			int blockY = j / 8;
			int blockIndex = (w * blockY + i) * 2;
			uint8_t pixels = bitmap[blockIndex];
			uint8_t maskPixels = bitmap[blockIndex + 1];
			uint8_t bitmask = 1 << (j % 8);

			if (maskPixels & bitmask)
			{
				if (x + i >= 0 && y + j >= 0)
					PutPixel(x + i, y + j, (pixels & bitmask) ? 1 : 0);
			}
		}
	}
}

void Platform::DrawSprite(int16_t x, int16_t y, const uint8_t* bitmap, const uint8_t* mask, uint8_t /*frame*/, uint8_t /*mask_frame*/)
{
	uint8_t w = bitmap[0];
	uint8_t h = bitmap[1];
	bitmap += 2;

	for (int j = 0; j < h; j++)
	{
		for (int i = 0; i < w; i++)
		{
			int blockY = j / 8;
			int blockIndex = w * blockY + i;
			uint8_t pixels = bitmap[blockIndex];
			uint8_t maskPixels = mask[blockIndex];
			uint8_t bitmask = 1 << (j % 8);

			if (maskPixels & bitmask)
			{
				if (x + i >= 0 && y + j >= 0)
					PutPixel(x + i, y + j, (pixels & bitmask) ? 1 : 0);
			}
		}
	}
}

void Platform::DrawVLine(uint8_t x, int8_t y1, int8_t y2, uint8_t pattern)
{
	for (int y = y1; y <= y2; y++)
	{
		if (y >= 0)
		{
			uint8_t patternIndex = y % 8;
			uint8_t mask = 1 << patternIndex;
			PutPixel(x, y, (mask & pattern) != 0 ? 1 : 0);
		}
	}
}

static void DrawBitmapInternal(const uint8_t* data, uint16_t x, uint16_t y, uint8_t w, uint8_t h)
{
	for (int j = 0; j < h; j++)
	{
		for (int i = 0; i < w; i++)
		{
			int blockX = i / 8;
			int blockY = j / 8;
			int blocksPerWidth = w / 8;
			int blockIndex = blockY * blocksPerWidth + blockX;
			uint8_t pixels = data[blockIndex * 8 + i % 8];
			uint8_t mask = 1 << (j % 8);
			if (x + i >= 0 && y + j >= 0)
				Platform::PutPixel(x + i, y + j, (pixels & mask) ? 1 : 0);
		}
	}
}

void Platform::DrawBitmap(int16_t x, int16_t y, const uint8_t* bitmap)
{
	DrawBitmapInternal(bitmap + 2, x, y, bitmap[0], bitmap[1]);
}

void Platform::DrawSolidBitmap(int16_t x, int16_t y, const uint8_t* bitmap)
{
	DrawBitmapInternal(bitmap + 2, x, y, bitmap[0], bitmap[1]);
}

void Platform::DrawBackground()
{
	for (int y = 0; y < DISPLAY_HEIGHT; y++)
	{
		for (int x = 0; x < DISPLAY_WIDTH; x++)
		{
			uint8_t col = y < DISPLAY_HEIGHT / 2
				? ((x | y) & 1 ? COLOUR_BLACK : COLOUR_WHITE)
				: ((x ^ y) & 1 ? COLOUR_BLACK : COLOUR_WHITE);
			PutPixel(x, y, col);
		}
	}
}

uint8_t* Platform::GetScreenBuffer()
{
	return sBuffer;
}

void Platform::PlaySound(const uint16_t* audioPattern)
{
	Play(audioPattern);
}

bool Platform::IsAudioEnabled()
{
	return isAudioEnabled;
}

void Platform::SetAudioEnabled(bool isEnabled)
{
	isAudioEnabled = isEnabled;
}

void Platform::ExpectLoadDelay()
{
}

uint8_t Platform::GetInput()
{
	uint8_t inputMask = 0;

	const uint8_t* keyStates = SDL_GetKeyboardState(nullptr);
	for (const auto& mapping : KeyMappings)
	{
		if (keyStates[mapping.key])
			inputMask |= mapping.mask;
	}

	inputMask |= PollControllerInput();

	return inputMask;
}

// ---------------------------------------------------------------------------
// Rendering + main loop
// ---------------------------------------------------------------------------
static void ResolveScreen(SDL_Surface* surface)
{
	Uint32 black = SDL_MapRGBA(surface->format, 0, 0, 0, 255);
	Uint32 white = SDL_MapRGBA(surface->format, 255, 255, 255, 255);
	int bpp = surface->format->BytesPerPixel;

	for (int y = 0; y < DISPLAY_HEIGHT; y++)
	{
		for (int x = 0; x < DISPLAY_WIDTH; x++)
		{
			Uint8* p = (Uint8*)surface->pixels + y * surface->pitch + x * bpp;
			*(Uint32*)p = GetPixel(x, y) ? white : black;
		}
	}
}

int main(int /*argc*/, char* /*argv*/[])
{
	SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight");
	SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER | SDL_INIT_JOYSTICK);

	SDL_CreateWindowAndRenderer(0, 0, SDL_WINDOW_FULLSCREEN, &AppWindow, &AppRenderer);
	SDL_RenderSetLogicalSize(AppRenderer, DISPLAY_WIDTH, DISPLAY_HEIGHT);

	ScreenSurface = SDL_CreateRGBSurface(0, DISPLAY_WIDTH, DISPLAY_HEIGHT, 32,
		0x000000ff, 0x0000ff00, 0x00ff0000, 0xff000000);
	ScreenTexture = SDL_CreateTexture(AppRenderer, SDL_PIXELFORMAT_ABGR8888,
		SDL_TEXTUREACCESS_STREAMING, ScreenSurface->w, ScreenSurface->h);

	OpenFirstAvailableController();

	SDL_AudioSpec wanted{};
	wanted.freq = audioSampleRate;
	wanted.format = AUDIO_U8;
	wanted.channels = 1;
	wanted.samples = 2048;
	wanted.callback = FillAudioBuffer;
	SDL_OpenAudio(&wanted, nullptr);
	SDL_PauseAudio(0);

	SeedRandom((uint16_t)SDL_GetTicks());
	Game::Init();

	bool running = true;
	while (running)
	{
		SDL_Event event;
		while (SDL_PollEvent(&event))
		{
			switch (event.type)
			{
			case SDL_QUIT:
				running = false;
				break;
			case SDL_CONTROLLERDEVICEADDED:
				if (!ActiveController)
					ActiveController = SDL_GameControllerOpen(event.cdevice.which);
				break;
			case SDL_CONTROLLERDEVICEREMOVED:
				if (ActiveController && event.cdevice.which == SDL_JoystickInstanceID(
						SDL_GameControllerGetJoystick(ActiveController)))
				{
					SDL_GameControllerClose(ActiveController);
					ActiveController = nullptr;
					OpenFirstAvailableController();
				}
				break;
			case SDL_KEYDOWN:
				if (event.key.keysym.sym == SDLK_AC_BACK)
					running = false;
				break;
			default:
				break;
			}
		}

		memset(ScreenSurface->pixels, 0, (size_t)ScreenSurface->format->BytesPerPixel * ScreenSurface->w * ScreenSurface->h);

		Game::Tick();
		Game::Draw();

		ResolveScreen(ScreenSurface);

		SDL_UpdateTexture(ScreenTexture, nullptr, ScreenSurface->pixels, ScreenSurface->pitch);
		SDL_RenderClear(AppRenderer);
		SDL_RenderCopy(AppRenderer, ScreenTexture, nullptr, nullptr);
		SDL_RenderPresent(AppRenderer);

		SDL_Delay(1000 / TARGET_FRAMERATE);
	}

	if (ActiveController)
		SDL_GameControllerClose(ActiveController);

	SDL_CloseAudio();
	SDL_DestroyTexture(ScreenTexture);
	SDL_FreeSurface(ScreenSurface);
	SDL_DestroyRenderer(AppRenderer);
	SDL_DestroyWindow(AppWindow);
	SDL_Quit();

	return 0;
}
