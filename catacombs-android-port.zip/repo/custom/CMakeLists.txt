cmake_minimum_required(VERSION 3.10)
project(catacombs3d)

# SDL2 is checked out (by the workflow) into app/jni/SDL as the full SDL2
# source tree, and built here as part of our own native build.
add_subdirectory(${CMAKE_CURRENT_SOURCE_DIR}/SDL ${CMAKE_BINARY_DIR}/SDL)

# All game-engine source files (copied in from the original Arduboy3D source
# plus our own AndroidMain.cpp) live flat in app/jni/src.
file(GLOB GAME_SOURCES ${CMAKE_CURRENT_SOURCE_DIR}/src/*.cpp)

add_library(main SHARED ${GAME_SOURCES})

target_include_directories(main PRIVATE
	${CMAKE_CURRENT_SOURCE_DIR}/src
)

set_target_properties(main PROPERTIES
	CXX_STANDARD 17
	CXX_STANDARD_REQUIRED ON
)

target_link_libraries(main SDL2)
