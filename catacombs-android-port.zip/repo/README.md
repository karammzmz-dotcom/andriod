# Catacombs of the Damned — Android port

This repo turns the original Arduboy game **"Catacombs of the Damned!"**
(Arduboy3D) into an Android APK, controllable only with a **physical/Bluetooth
game controller or a physical/Bluetooth keyboard** — there are no on-screen
touch controls.

It works by reusing the game's existing SDL2 port (`Source/Windows`) instead
of the AVR/Arduino sketch: the raycasting engine, map generator, enemies,
etc. are all plain portable C++ already, and only the "Platform" layer (input,
pixel output, sound) needs a backend. The repo supplies an Android/SDL2
Platform backend (`custom/AndroidMain.cpp`) in place of the Arduino one.

## How it's built

Everything happens in `.github/workflows/build-and-unzip.yml`, which runs on
GitHub's servers (not on your machine):

1. **Unzip** — unpacks `Arduboy3D-1_0.zip` (the original source you uploaded,
   committed in this repo) to get at the game's C++ source.
2. **Fetch SDL2** — clones the official SDL2 repo, which ships a ready-made,
   known-working Android Studio project template (`android-project/`,
   including the Java `SDLActivity`, gradle wrapper, manifest, etc.). We don't
   hand-roll any of that scaffolding — it's the real thing.
3. **Assemble** — copies the game's `.cpp`/`.h` files plus our own
   `AndroidMain.cpp` (controller + keyboard input, no touch) and a small
   patched `Defines.h` (removes the AVR-only `#include <avr/pgmspace.h>`
   branch) into the SDL2 Android project's `app/jni/src/`, and drops in our
   own `CMakeLists.txt` to compile it all against SDL2.
4. **Build** — installs the Android SDK/NDK/CMake, generates a Gradle
   wrapper, and runs `./gradlew assembleDebug`.
5. Uploads the resulting **debug APK** as a workflow artifact
   (`catacombs-android-debug-apk`) that you download from the Actions run page.

## Using it

1. Create a new GitHub repository and push everything in this zip to it
   (including `Arduboy3D-1_0.zip` at the repo root — don't unzip it, the
   workflow does that).
2. Go to the **Actions** tab, select **"Build and Unzip"**, and click
   **"Run workflow"** (it also runs automatically on every push to
   `main`/`master`).
3. When it finishes, open the run and download the `catacombs-android-debug-apk`
   artifact. Unzip it to get `app-debug.apk`.
4. Install it on your device (`adb install app-debug.apk`, or copy it to the
   device and open it — you'll need "install unknown apps" enabled since this
   is a debug build, not from the Play Store).

## Controls

- **D-pad / left stick**: move
- **A / X button**: fire
- **B / Y button**: secondary action
- Shoulder triggers are also mapped as alternates for A/B
- Keyboard: arrow keys or WASD to move, Z/J/Space to fire, X/K/Enter for the
  secondary action
- There is intentionally **no on-screen touch UI** — connect a Bluetooth or
  USB controller, or a keyboard, before launching.

## Known limitations / things you may want to tweak

- This is a **debug, unsigned APK**. For a Play Store release you'd want to
  set up a signing keystore and an `assembleRelease` build in the workflow.
- The app keeps the default SDL template's package name (`org.libsdl.app`)
  and icon. Rename the package / add your own launcher icon in
  `android/app/build.gradle`, `AndroidManifest.xml` and `res/` if you want to
  publish it properly. The workflow regenerates `android/` from scratch each
  run, so make any such changes to the files under `custom/` (or add new sed
  patches in the workflow) rather than editing the generated `android/`
  folder directly, or they'll be overwritten on the next run.
- Background/foreground app-lifecycle handling (what happens when you alt-tab
  away and back) uses SDL's defaults rather than a custom pause screen.
- Sounds use a simple square-wave synth (ported from `WinMain.cpp`'s
  approach), not the exact AVR tone hardware — it should sound essentially
  the same as the Windows build of this game.

## Repo layout

```
Arduboy3D-1_0.zip          original uploaded source (unzipped by CI)
.github/workflows/
  build-and-unzip.yml       the CI build described above
custom/
  AndroidMain.cpp           SDL2 Platform:: backend (controller + keyboard)
  Defines.h                 patched, portable version of the game's Defines.h
  CMakeLists.txt            native build script for app/jni
README.md
```
