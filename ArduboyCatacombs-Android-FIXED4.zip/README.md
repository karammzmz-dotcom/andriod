# Arduboy Catacombs — Android port

Android port of the supplied Arduboy3D Catacombs C++ game. The original game simulation, renderer, map generation, player, enemies, menus and sprite data are compiled into a native Android library. The Android front end presents the original 128×64 monochrome framebuffer scaled to fit the landscape screen.

## Controls — no touchscreen controls

The app has **no on-screen buttons**. Touching the screen does nothing.

| Action | Keyboard | Controller |
|---|---|---|
| Up / down / left / right | Arrow keys or W/A/S/D | D-pad or left stick |
| A | Z, Enter or Space | A or X |
| B | X or Escape | B or Y |

USB and Bluetooth gamepads supported by Android should work when they expose standard Android gamepad key/axis events. Button labels can vary by controller.

## Build with GitHub Actions

1. Create a GitHub repository and upload the **contents** of this folder (so `app/`, `build.gradle`, `settings.gradle`, and `.github/` are at repository root).
2. Open **Actions**.
3. Run **Build Android APK** (or push to `main` / `master`).
4. Open the completed workflow run and download the `Catacombs-Android-debug` artifact.
5. Extract that artifact ZIP to get `app-debug.apk`, then install it.

`build.yml` builds the APK. `unzip.yml` is a manual workflow that optionally extracts the original `Arduboy3D-1.0.zip` if you also put that archive at the repository root, then builds the APK. The Android project already contains the extracted game source, so the extra archive is not required.

## Technical notes

- Android min SDK: 23.
- Architectures: `arm64-v8a`, `armeabi-v7a`, and `x86_64`.
- Native game loop: 30 FPS.
- Original 128×64 monochrome display buffer, scaled to fit landscape.
- No touch UI, virtual joystick, or touch-to-move logic.
- Sound output is currently disabled in this Android port.

## Source and attribution

The game source and assets are based on the user-provided `Arduboy3D-1.0.zip`. See `THIRD_PARTY_LICENSE.txt` for the included source license.
