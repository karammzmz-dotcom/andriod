#include <jni.h>
#include <cstdint>
#include <cstring>
#include "game/Defines.h"
#include "game/Platform.h"
#include "game/Game.h"
#include "game/FixedMath.h"

static uint8_t inputMask = 0;
static uint8_t screenBuffer[DISPLAY_WIDTH * DISPLAY_HEIGHT / 8] = {};
static bool initialized = false;

uint8_t Platform::GetInput() { return inputMask; }
void Platform::SetLED(uint8_t, uint8_t, uint8_t) {}
void Platform::PlaySound(const uint16_t*) {}
bool Platform::IsAudioEnabled() { return true; }
void Platform::SetAudioEnabled(bool) {}
void Platform::ExpectLoadDelay() {}
uint8_t* Platform::GetScreenBuffer() { return screenBuffer; }

void Platform::FillScreen(uint8_t colour) {
    std::memset(screenBuffer, colour ? 0xFF : 0x00, sizeof(screenBuffer));
}
void Platform::PutPixel(uint8_t x, uint8_t y, uint8_t colour) {
    if (x >= DISPLAY_WIDTH || y >= DISPLAY_HEIGHT) return;
    const int index = (y & 0xF8) * DISPLAY_WIDTH / 8 + x;
    const uint8_t bit = static_cast<uint8_t>(1u << (y & 7));
    if (colour) screenBuffer[index] |= bit;
    else screenBuffer[index] &= static_cast<uint8_t>(~bit);
}
void Platform::DrawVLine(uint8_t x, int8_t y0, int8_t y1, uint8_t pattern) {
    if (x >= DISPLAY_WIDTH || y1 < y0) return;
    for (int y = y0; y <= y1; ++y)
        if (y >= 0 && y < DISPLAY_HEIGHT)
            PutPixel(x, static_cast<uint8_t>(y), (pattern >> (y & 7)) & 1);
}
void Platform::DrawBitmap(int16_t x, int16_t y, const uint8_t* bitmap) {
    const uint8_t w = pgm_read_byte(bitmap), h = pgm_read_byte(bitmap + 1);
    const uint8_t* data = bitmap + 2;
    const int blocksWide = (w + 7) / 8;
    for (int j=0;j<h;++j) for (int i=0;i<w;++i) {
        const int idx = ((j/8)*blocksWide + i/8)*8 + (i%8);
        const bool on = (pgm_read_byte(data + idx) >> (j&7)) & 1;
        if (x+i>=0 && x+i<DISPLAY_WIDTH && y+j>=0 && y+j<DISPLAY_HEIGHT)
            PutPixel(static_cast<uint8_t>(x+i), static_cast<uint8_t>(y+j), on);
    }
}
void Platform::DrawSolidBitmap(int16_t x, int16_t y, const uint8_t* bitmap) {
    const uint8_t w = pgm_read_byte(bitmap), h = pgm_read_byte(bitmap + 1);
    for (int j=0;j<h;++j) for (int i=0;i<w;++i)
        if (x+i>=0 && x+i<DISPLAY_WIDTH && y+j>=0 && y+j<DISPLAY_HEIGHT)
            PutPixel(static_cast<uint8_t>(x+i), static_cast<uint8_t>(y+j), 0);
    DrawBitmap(x,y,bitmap);
}
void Platform::DrawSprite(int16_t x, int16_t y, const uint8_t* bitmap, uint8_t) {
    const uint8_t w=pgm_read_byte(bitmap), h=pgm_read_byte(bitmap+1);
    bitmap+=2;
    for(int j=0;j<h;++j) for(int i=0;i<w;++i) {
        const int idx=(w*(j/8)+i)*2;
        const uint8_t px=pgm_read_byte(bitmap+idx), mask=pgm_read_byte(bitmap+idx+1);
        const uint8_t bit=1u<<(j&7);
        if((mask&bit) && x+i>=0 && x+i<DISPLAY_WIDTH && y+j>=0 && y+j<DISPLAY_HEIGHT)
            PutPixel(static_cast<uint8_t>(x+i),static_cast<uint8_t>(y+j),(px&bit)!=0);
    }
}
void Platform::DrawSprite(int16_t x, int16_t y, const uint8_t* bitmap,
                           const uint8_t* mask, uint8_t, uint8_t) {
    const uint8_t w=pgm_read_byte(bitmap), h=pgm_read_byte(bitmap+1);
    bitmap+=2;
    for(int j=0;j<h;++j) for(int i=0;i<w;++i) {
        const int idx=w*(j/8)+i;
        const uint8_t px=pgm_read_byte(bitmap+idx), m=pgm_read_byte(mask+idx);
        const uint8_t bit=1u<<(j&7);
        if((m&bit) && x+i>=0 && x+i<DISPLAY_WIDTH && y+j>=0 && y+j<DISPLAY_HEIGHT)
            PutPixel(static_cast<uint8_t>(x+i),static_cast<uint8_t>(y+j),(px&bit)!=0);
    }
}
void Platform::DrawBackground() {
    for(int y=0;y<DISPLAY_HEIGHT;++y) for(int x=0;x<DISPLAY_WIDTH;++x)
        PutPixel(x,y, y<DISPLAY_HEIGHT/2 ? ((x|y)&1)==0 : ((x^y)&1)!=0);
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_catacombs_game_MainActivity_nativeFrame(JNIEnv* env, jclass, jint keys) {
    inputMask = static_cast<uint8_t>(keys & 0x3F);
    if (!initialized) {
        SeedRandom(0x5A17);
        Game::Init();
        initialized = true;
    }
    Game::Tick();
    Game::Draw();
    jint pixels[DISPLAY_WIDTH*DISPLAY_HEIGHT];
    for(int y=0;y<DISPLAY_HEIGHT;++y) for(int x=0;x<DISPLAY_WIDTH;++x) {
        const int index=(y&0xF8)*DISPLAY_WIDTH/8+x;
        const bool white=(screenBuffer[index]>>(y&7))&1;
        pixels[y*DISPLAY_WIDTH+x] = white ? 0xFFFFFFFF : 0xFF000000;
    }
    jintArray out=env->NewIntArray(DISPLAY_WIDTH*DISPLAY_HEIGHT);
    env->SetIntArrayRegion(out,0,DISPLAY_WIDTH*DISPLAY_HEIGHT,pixels);
    return out;
}
