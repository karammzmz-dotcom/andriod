package com.catacombs.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.content.Context;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    static { System.loadLibrary("catacombs"); }
    private static native int[] nativeFrame(int keys);
    private GameView gameView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        gameView = new GameView(this);
        setContentView(gameView);
        gameView.setFocusable(true);
        gameView.setFocusableInTouchMode(true);
        gameView.requestFocus();
    }
    @Override protected void onResume() { super.onResume(); if (gameView != null) gameView.start(); }
    @Override protected void onPause() { if (gameView != null) gameView.stop(); super.onPause(); }

    private class GameView extends SurfaceView implements Runnable {
        private final SurfaceHolder holder;
        private final Set<Integer> held = new HashSet<>();
        private volatile boolean running;
        private Thread thread;
        private final Bitmap bitmap = Bitmap.createBitmap(128,64,Bitmap.Config.ARGB_8888);
        private final Paint paint = new Paint();
        private int axisMask = 0;
        GameView(Context c) { super(c); holder=getHolder(); paint.setFilterBitmap(false); setFocusable(true); }
        void start() { if (running) return; running=true; thread=new Thread(this,"CatacombsGame"); thread.start(); }
        void stop() { running=false; if(thread!=null) try { thread.join(500); } catch(InterruptedException ignored) {} }
        private int mask() {
            int m=axisMask;
            for(int k:held) m |= keyMask(k);
            return m;
        }
        private int keyMask(int key) {
            switch(key) {
                case KeyEvent.KEYCODE_DPAD_LEFT: case KeyEvent.KEYCODE_A: return 1;
                case KeyEvent.KEYCODE_DPAD_RIGHT: case KeyEvent.KEYCODE_D: return 2;
                case KeyEvent.KEYCODE_DPAD_UP: case KeyEvent.KEYCODE_W: return 4;
                case KeyEvent.KEYCODE_DPAD_DOWN: case KeyEvent.KEYCODE_S: return 8;
                case KeyEvent.KEYCODE_Z: case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_SPACE:
                case KeyEvent.KEYCODE_BUTTON_A: case KeyEvent.KEYCODE_BUTTON_X: return 16;
                case KeyEvent.KEYCODE_X: case KeyEvent.KEYCODE_ESCAPE: case KeyEvent.KEYCODE_BUTTON_B:
                case KeyEvent.KEYCODE_BUTTON_Y: return 32;
            }
            return 0;
        }
        @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
            if(keyMask(keyCode)!=0) { held.add(keyCode); return true; }
            return super.onKeyDown(keyCode,event);
        }
        @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
            if(keyMask(keyCode)!=0) { held.remove(keyCode); return true; }
            return super.onKeyUp(keyCode,event);
        }
        @Override public boolean onGenericMotionEvent(MotionEvent e) {
            if ((e.getSource() & InputDevice.SOURCE_JOYSTICK)==InputDevice.SOURCE_JOYSTICK &&
                e.getAction()==MotionEvent.ACTION_MOVE) {
                float x=e.getAxisValue(MotionEvent.AXIS_X), y=e.getAxisValue(MotionEvent.AXIS_Y);
                float hx=e.getAxisValue(MotionEvent.AXIS_HAT_X), hy=e.getAxisValue(MotionEvent.AXIS_HAT_Y);
                if(Math.abs(hx)>0.4f) x=hx; if(Math.abs(hy)>0.4f) y=hy;
                axisMask=0;
                if(x < -0.45f) axisMask|=1; if(x > 0.45f) axisMask|=2;
                if(y < -0.45f) axisMask|=4; if(y > 0.45f) axisMask|=8;
                return true;
            }
            return super.onGenericMotionEvent(e);
        }
        @Override public boolean onTouchEvent(MotionEvent e) { return true; } // deliberately no touch controls
        @Override public void run() {
            final long frameNs=1_000_000_000L/30;
            long next=System.nanoTime();
            while(running) {
                int[] px=nativeFrame(mask());
                bitmap.setPixels(px,0,128,0,0,128,64);
                if(holder.getSurface().isValid()) {
                    Canvas c=null;
                    try {
                        c=holder.lockCanvas();
                        if(c!=null) {
                            c.drawColor(Color.BLACK);
                            float scale=Math.min(c.getWidth()/128f,c.getHeight()/64f);
                            float w=128*scale, h=64*scale;
                            float left=(c.getWidth()-w)/2f, top=(c.getHeight()-h)/2f;
                            c.drawBitmap(bitmap,null,new RectF(left,top,left+w,top+h),paint);
                        }
                    } finally { if(c!=null) holder.unlockCanvasAndPost(c); }
                }
                next+=frameNs;
                long wait=next-System.nanoTime();
                if(wait>0) try { Thread.sleep(wait/1_000_000L,(int)(wait%1_000_000L)); }
                catch(InterruptedException ignored) {}
                else next=System.nanoTime();
            }
        }
    }
}
